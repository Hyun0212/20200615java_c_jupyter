#include <iostream>
#include <stdio.h>

int main() {
  for(int i=1;i<6;i++){
    for(int j=1;j<=i;j++){
     printf("*");
    }
    printf( "\n");
  }
printf("------------------");
printf("\n");
  for(int a=1;a<6;a++){
    for(int b=5;b>=a;b--){
     printf("%d",b);
    }
    printf( "\n");
  }
}